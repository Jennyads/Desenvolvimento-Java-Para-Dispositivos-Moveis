package br.com.jeniffer.controlechavespix;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etChave;
    private Spinner spTipoChave;
    private RadioGroup rgDono;
    private CheckBox cbFavorita;
    private Button btnLimpar, btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setDisplayHomeAsUpEnabled(true);
            ab.setTitle("Cadastro de Chave PIX");
        }

        etNome = findViewById(R.id.etNome);
        etChave = findViewById(R.id.etChave);
        spTipoChave = findViewById(R.id.spTipoChave);
        rgDono = findViewById(R.id.rgDono);
        cbFavorita = findViewById(R.id.cbFavorita);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnSalvar = findViewById(R.id.btnSalvar);

        configurarSpinner();

        btnLimpar.setOnClickListener(v -> limparFormulario());
        btnSalvar.setOnClickListener(v -> salvarComValidacao());
    }

    private void configurarSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.tipos_chave_pix,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTipoChave.setAdapter(adapter);
    }

    private void limparFormulario() {
        etNome.setText("");
        etChave.setText("");
        rgDono.clearCheck();
        cbFavorita.setChecked(false);
        spTipoChave.setSelection(0);

        etNome.requestFocus();
        Toast.makeText(this, "Formulário limpo.", Toast.LENGTH_SHORT).show();
    }

    private void salvarComValidacao() {

        String nome = etNome.getText().toString().trim();
        String chave = etChave.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Erro: preencha o Nome/Apelido.", Toast.LENGTH_SHORT).show();
            etNome.requestFocus();
            return;
        }

        if (chave.isEmpty()) {
            Toast.makeText(this, "Erro: preencha a Chave.", Toast.LENGTH_SHORT).show();
            etChave.requestFocus();
            return;
        }

        int selecionado = rgDono.getCheckedRadioButtonId();
        if (selecionado == -1) {
            Toast.makeText(this, "Erro: selecione o Dono da chave.", Toast.LENGTH_SHORT).show();
            return;
        }

        String tipo = spTipoChave.getSelectedItem().toString();
        String dono = (selecionado == R.id.rbPropria) ? "Própria" : "Terceiro";
        boolean favorita = cbFavorita.isChecked();

        Intent data = new Intent();
        data.putExtra(ListaChavesActivity.EXTRA_APELIDO, nome);
        data.putExtra(ListaChavesActivity.EXTRA_CHAVE, chave);
        data.putExtra(ListaChavesActivity.EXTRA_TIPO, tipo);
        data.putExtra(ListaChavesActivity.EXTRA_DONO, dono);
        data.putExtra(ListaChavesActivity.EXTRA_FAVORITA, favorita);

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}