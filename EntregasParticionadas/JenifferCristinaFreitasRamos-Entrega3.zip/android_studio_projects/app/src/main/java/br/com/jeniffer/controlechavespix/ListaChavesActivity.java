package br.com.jeniffer.controlechavespix;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaChavesActivity extends AppCompatActivity {

    public static final String EXTRA_APELIDO = "EXTRA_APELIDO";
    public static final String EXTRA_CHAVE = "EXTRA_CHAVE";
    public static final String EXTRA_TIPO = "EXTRA_TIPO";
    public static final String EXTRA_DONO = "EXTRA_DONO";
    public static final String EXTRA_FAVORITA = "EXTRA_FAVORITA";

    private ArrayList<ChavePix> lista;
    private ChavePixAdapter adapter;

    private final ActivityResultLauncher<Intent> cadastroLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();

                    String apelido = data.getStringExtra(EXTRA_APELIDO);
                    String chave = data.getStringExtra(EXTRA_CHAVE);
                    String tipo = data.getStringExtra(EXTRA_TIPO);
                    String dono = data.getStringExtra(EXTRA_DONO);
                    boolean favorita = data.getBooleanExtra(EXTRA_FAVORITA, false);

                    ChavePix novo = new ChavePix(apelido, chave, tipo, dono, favorita);
                    lista.add(novo);
                    adapter.notifyDataSetChanged();

                    Toast.makeText(this, "Adicionado: " + apelido, Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_chaves);

        Button btnAdicionar = findViewById(R.id.btnAdicionar);
        Button btnSobre = findViewById(R.id.btnSobre);
        ListView lvChaves = findViewById(R.id.lvChaves);

        lista = new ArrayList<>();
        adapter = new ChavePixAdapter(this, lista);
        lvChaves.setAdapter(adapter);

        lvChaves.setOnItemClickListener((parent, view, position, id) -> {
            ChavePix clicado = lista.get(position);
            String msg = "Clicado: " + clicado.getApelido() + " • " + clicado.getTipoChave();
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });

        btnAdicionar.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            cadastroLauncher.launch(intent);
        });

        btnSobre.setOnClickListener(v -> {
            Intent intent = new Intent(this, SobreActivity.class);
            startActivity(intent);
        });
    }
}