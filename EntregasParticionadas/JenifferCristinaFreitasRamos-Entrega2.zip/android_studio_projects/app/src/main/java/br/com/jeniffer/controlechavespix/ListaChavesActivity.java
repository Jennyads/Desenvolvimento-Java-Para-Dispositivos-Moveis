package br.com.jeniffer.controlechavespix;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaChavesActivity extends AppCompatActivity {

    private ArrayList<ChavePix> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_chaves);

        ListView lvChaves = findViewById(R.id.lvChaves);

        lista = carregarChavesDoResource();

        ChavePixAdapter adapter = new ChavePixAdapter(this, lista);
        lvChaves.setAdapter(adapter);

        lvChaves.setOnItemClickListener((parent, view, position, id) -> {
            ChavePix clicado = lista.get(position);
            String msg = "Clicado: " + clicado.getApelido() + " • " + clicado.getTipoChave();
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });
    }

    private ArrayList<ChavePix> carregarChavesDoResource() {
        String[] apelidos = getResources().getStringArray(R.array.pix_apelidos);
        String[] chaves = getResources().getStringArray(R.array.pix_chaves);
        String[] tipos = getResources().getStringArray(R.array.pix_tipos);
        String[] donos = getResources().getStringArray(R.array.pix_donos);
        String[] favoritas = getResources().getStringArray(R.array.pix_favoritas);

        int total = Math.min(
                apelidos.length,
                Math.min(chaves.length,
                        Math.min(tipos.length,
                                Math.min(donos.length, favoritas.length)))
        );

        ArrayList<ChavePix> lista = new ArrayList<>();

        for (int i = 0; i < total; i++) {
            boolean fav = Boolean.parseBoolean(favoritas[i]);
            lista.add(new ChavePix(apelidos[i], chaves[i], tipos[i], donos[i], fav));
        }

        return lista;
    }
}