package br.com.jeniffer.controlechavespix;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ChavePixAdapter extends ArrayAdapter<ChavePix> {

    public ChavePixAdapter(Context context, List<ChavePix> itens) {
        super(context, 0, itens);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_chave_pix, parent, false);
        }

        ChavePix item = getItem(position);

        TextView tvApelido = view.findViewById(R.id.tvApelido);
        TextView tvTipoDono = view.findViewById(R.id.tvTipoDono);
        TextView tvChave = view.findViewById(R.id.tvChave);
        TextView tvFavorita = view.findViewById(R.id.tvFavorita);

        if (item != null) {
            tvApelido.setText(item.getApelido());
            tvTipoDono.setText(item.getTipoChave() + " • " + item.getDono());
            tvChave.setText(item.getChave());
            tvFavorita.setText(item.isFavorita() ? "★ Favorita" : "☆ Não favorita");
        }

        return view;
    }
}