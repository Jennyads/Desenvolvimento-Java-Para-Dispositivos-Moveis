package br.com.jeniffer.controlechavespix;

public class ChavePix {

    private final String apelido;
    private final String chave;
    private final String tipoChave;
    private final String dono;
    private final boolean favorita;

    public ChavePix(String apelido, String chave, String tipoChave, String dono, boolean favorita) {
        this.apelido = apelido;
        this.chave = chave;
        this.tipoChave = tipoChave;
        this.dono = dono;
        this.favorita = favorita;
    }

    public String getApelido() { return apelido; }
    public String getChave() { return chave; }
    public String getTipoChave() { return tipoChave; }
    public String getDono() { return dono; }
    public boolean isFavorita() { return favorita; }
}