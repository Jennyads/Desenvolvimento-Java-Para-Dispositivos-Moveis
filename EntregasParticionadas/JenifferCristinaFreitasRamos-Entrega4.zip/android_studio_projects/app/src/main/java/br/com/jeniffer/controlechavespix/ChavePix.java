package br.com.jeniffer.controlechavespix;

public class ChavePix {

    private String apelido;
    private String chave;
    private String tipoChave;
    private String dono;
    private boolean favorita;

    public ChavePix(String apelido, String chave, String tipoChave, String dono, boolean favorita) {
        this.apelido = apelido;
        this.chave = chave;
        this.tipoChave = tipoChave;
        this.dono = dono;
        this.favorita = favorita;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public String getChave() {
        return chave;
    }

    public void setChave(String chave) {
        this.chave = chave;
    }

    public String getTipoChave() {
        return tipoChave;
    }

    public void setTipoChave(String tipoChave) {
        this.tipoChave = tipoChave;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public boolean isFavorita() {
        return favorita;
    }

    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }
}