package br.com.jeniffer.controlechavespix;

import android.util.Log;


import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListaChavesActivity extends AppCompatActivity {

    public static final String EXTRA_APELIDO = "EXTRA_APELIDO";
    public static final String EXTRA_CHAVE = "EXTRA_CHAVE";
    public static final String EXTRA_TIPO = "EXTRA_TIPO";
    public static final String EXTRA_DONO = "EXTRA_DONO";
    public static final String EXTRA_FAVORITA = "EXTRA_FAVORITA";
    public static final String EXTRA_POSICAO = "EXTRA_POSICAO";
    public static final String EXTRA_MODO_EDICAO = "EXTRA_MODO_EDICAO";

    private ArrayList<ChavePix> lista;
    private ChavePixAdapter adapter;
    private int posicaoSelecionada = -1;

    private final ActivityResultLauncher<Intent> cadastroLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();

                    String apelido = data.getStringExtra(EXTRA_APELIDO);
                    String chave = data.getStringExtra(EXTRA_CHAVE);
                    String tipo = data.getStringExtra(EXTRA_TIPO);
                    String dono = data.getStringExtra(EXTRA_DONO);
                    boolean favorita = data.getBooleanExtra(EXTRA_FAVORITA, false);
                    int posicao = data.getIntExtra(EXTRA_POSICAO, -1);
                    boolean modoEdicao = data.getBooleanExtra(EXTRA_MODO_EDICAO, false);

                    if (modoEdicao && posicao >= 0 && posicao < lista.size()) {
                        ChavePix item = lista.get(posicao);
                        item.setApelido(apelido);
                        item.setChave(chave);
                        item.setTipoChave(tipo);
                        item.setDono(dono);
                        item.setFavorita(favorita);
                        Toast.makeText(this, "Item editado: " + apelido, Toast.LENGTH_SHORT).show();
                    } else {
                        ChavePix novo = new ChavePix(apelido, chave, tipo, dono, favorita);
                        lista.add(novo);
                        Toast.makeText(this, "Adicionado: " + apelido, Toast.LENGTH_SHORT).show();
                    }

                    adapter.notifyDataSetChanged();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_chaves);

        ListView lvChaves = findViewById(R.id.lvChaves);

        lista = new ArrayList<>();
        adapter = new ChavePixAdapter(this, lista);
        lvChaves.setAdapter(adapter);

        registerForContextMenu(lvChaves);

        lvChaves.setOnItemClickListener((parent, view, position, id) -> {
            ChavePix clicado = lista.get(position);
            Log.d("PIX_APP", "Item clicado: " + clicado.getApelido());
            String msg = "Clicado: " + clicado.getApelido() + " • " + clicado.getTipoChave();
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_lista, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuAdicionar) {
            Intent intent = new Intent(this, MainActivity.class);
            cadastroLauncher.launch(intent);
            return true;
        } else if (item.getItemId() == R.id.menuSobre) {
            Intent intent = new Intent(this, SobreActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_contexto_item, menu);
        menu.setHeaderTitle("Opções do item");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        posicaoSelecionada = info.position;
        ChavePix selecionado = lista.get(posicaoSelecionada);

        if (item.getItemId() == R.id.menuEditar) {

            Log.d("PIX_APP", "Editar item posição: " + posicaoSelecionada);

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra(EXTRA_APELIDO, selecionado.getApelido());
            intent.putExtra(EXTRA_CHAVE, selecionado.getChave());
            intent.putExtra(EXTRA_TIPO, selecionado.getTipoChave());
            intent.putExtra(EXTRA_DONO, selecionado.getDono());
            intent.putExtra(EXTRA_FAVORITA, selecionado.isFavorita());
            intent.putExtra(EXTRA_POSICAO, posicaoSelecionada);
            intent.putExtra(EXTRA_MODO_EDICAO, true);
            cadastroLauncher.launch(intent);
            return true;
        } else if (item.getItemId() == R.id.menuExcluir) {

            Log.d("PIX_APP", "Excluir item posição: " + posicaoSelecionada);

            lista.remove(posicaoSelecionada);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Item excluído.", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onContextItemSelected(item);
    }
}