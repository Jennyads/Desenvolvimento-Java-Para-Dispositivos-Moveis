package br.com.jeniffer.controlechavespix;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etChave;
    private Spinner spTipoChave;
    private RadioGroup rgDono;
    private CheckBox cbFavorita;
    private Button btnLimpar, btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etChave = findViewById(R.id.etChave);
        spTipoChave = findViewById(R.id.spTipoChave);
        rgDono = findViewById(R.id.rgDono);
        cbFavorita = findViewById(R.id.cbFavorita);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnSalvar = findViewById(R.id.btnSalvar);

        configurarSpinner();

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparFormulario();
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarComValidacao();
            }
        });
    }

    private void configurarSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.tipos_chave_pix,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTipoChave.setAdapter(adapter);
    }

    private void limparFormulario() {
        etNome.setText("");
        etChave.setText("");
        rgDono.clearCheck();
        cbFavorita.setChecked(false);
        spTipoChave.setSelection(0);

        etNome.requestFocus();
        Toast.makeText(this, "Formulário limpo.", Toast.LENGTH_SHORT).show();
    }

    private void salvarComValidacao() {
        String nome = etNome.getText().toString().trim();
        String chave = etChave.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Erro: informe o Nome/Apelido.", Toast.LENGTH_SHORT).show();
            etNome.requestFocus();
            return;
        }

        if (chave.isEmpty()) {
            Toast.makeText(this, "Erro: informe a Chave PIX.", Toast.LENGTH_SHORT).show();
            etChave.requestFocus();
            return;
        }

        int idSelecionado = rgDono.getCheckedRadioButtonId();
        if (idSelecionado == -1) {
            Toast.makeText(this, "Erro: selecione Própria ou Terceiro.", Toast.LENGTH_SHORT).show();
            return;
        }

        String tipoChave = spTipoChave.getSelectedItem().toString();
        boolean favorita = cbFavorita.isChecked();

        String dono = (idSelecionado == R.id.rbPropria) ? "Própria" : "Terceiro";

        String resumo = "Salvo: " + nome + " | " + tipoChave + " | " + dono +
                (favorita ? " | Favorita" : "");

        Toast.makeText(this, resumo, Toast.LENGTH_SHORT).show();
    }
}